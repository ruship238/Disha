export default [
    {
        id: 1,
        name: "Frontend",
    },
    {
        id: 2,
        name: "Backend",
    },
    {
        id: 3,
        name: "React",
    },
    {
        id: 4,
        name: "Devops",
    },
    {
        id: 5,
        name: "Cyber Security",
    },
    {
        id: 6,
        name: "Android",
    }
]
