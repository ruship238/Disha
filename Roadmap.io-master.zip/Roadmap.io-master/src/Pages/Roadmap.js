import React from "react"

function Roadmap(){
  return(
    <h1>roadmaps</h1>
  )
}

export default  Roadmap

/*
 this will fetch data from backend and display all the roadmaps roadmap
*/
